import type { FarmerPriorities, PriorityKey, RotationStrategy } from "./types";

export const PRIORITY_LABELS: Record<PriorityKey, string> = {
  waterConservation: "Water conservation",
  soilOrganicMatter: "Soil organic matter",
  erosionReduction: "Erosion reduction",
  nitrogenFixation: "Nitrogen fixation",
  forageValue: "Forage value",
  marketSuitability: "Market suitability",
  pestDisruption: "Pest disruption",
  riskTolerance: "Risk tolerance",
};

export const DEFAULT_PRIORITIES: FarmerPriorities = {
  waterConservation: 7, soilOrganicMatter: 7, erosionReduction: 5,
  nitrogenFixation: 5, forageValue: 4, marketSuitability: 6,
  pestDisruption: 5, riskTolerance: 5,
};

const TEMPLATES = [
  {
    id: "existing", name: "Existing rotation",
    description: "Your current sequence, used as the baseline.",
    crops: ["Cash crop A", "Cash crop B"],
    scores: { waterConservation: 5, soilOrganicMatter: 4, erosionReduction: 4, nitrogenFixation: 3, forageValue: 5, marketSuitability: 8, pestDisruption: 3, riskTolerance: 5 },
    evidence: ["Baseline data."], gaps: ["No new data."], risks: ["Existing decline continues."],
    narrative: "Why this was suggested: This is your current baseline. What supports it: It reflects your current market channels. What is missing: No new soil data is introduced. What needs local review: Whether your current yield decline is acceptable."
  },
  {
    id: "soil-rebuilder", name: "Soil-Rebuilder",
    description: "Adds deep-rooting cover crop and legumes.",
    crops: ["Cover crop", "Legume", "Cash crop"],
    scores: { waterConservation: 6, soilOrganicMatter: 9, erosionReduction: 8, nitrogenFixation: 9, forageValue: 6, marketSuitability: 5, pestDisruption: 8, riskTolerance: 4 },
    evidence: ["Legumes fix N."], gaps: ["Local variety not modeled."], risks: ["Timing collision."],
    narrative: "Why this was suggested: High score for soil organic matter and nitrogen. What supports it: Legumes add nitrogen and deep roots break compaction. What is missing: Local seed variety performance. What needs local review: Cover crop termination timing before cash crop planting."
  },
  {
    id: "water-saver", name: "Water-Saver",
    description: "Swaps thirsty crops for drought-tolerant ones.",
    crops: ["Drought crop", "Residue rotation"],
    scores: { waterConservation: 9, soilOrganicMatter: 6, erosionReduction: 7, nitrogenFixation: 4, forageValue: 5, marketSuitability: 6, pestDisruption: 6, riskTolerance: 7 },
    evidence: ["Residue cuts evaporation."], gaps: ["Market demand unknown."], risks: ["Thinner market."],
    narrative: "Why this was suggested: Your water conservation priority is high. What supports it: Residue retention drastically cuts evaporation. What is missing: Buyer demand in your region. What needs local review: Equipment compatibility for heavy residue."
  }
];

export function scoreStrategies(priorities: FarmerPriorities): RotationStrategy[] {
  const keys = Object.keys(PRIORITY_LABELS) as PriorityKey[];
  const total = keys.reduce((s, k) => s + priorities[k], 0) || 1;

  return TEMPLATES.map((t) => {
    let score = 0;
    keys.forEach(k => {
      score += (priorities[k] / total) * t.scores[k];
    });
    
    return {
      ...t,
      overallScore: Number(score.toFixed(2))
    };
  }).sort((a, b) => b.overallScore - a.overallScore);
}