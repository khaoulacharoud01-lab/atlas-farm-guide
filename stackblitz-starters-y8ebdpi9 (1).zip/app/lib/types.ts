export type PriorityKey =
  | "waterConservation"
  | "soilOrganicMatter"
  | "erosionReduction"
  | "nitrogenFixation"
  | "forageValue"
  | "marketSuitability"
  | "pestDisruption"
  | "riskTolerance";

export type FarmerPriorities = Record<PriorityKey, number>;

export interface RotationStrategy {
  id: string;
  name: string;
  description: string;
  crops: string[];
  scores: Record<PriorityKey, number>;
  overallScore: number;
  evidence: string[];
  gaps: string[];
  risks: string[];
  narrative?: string;
}