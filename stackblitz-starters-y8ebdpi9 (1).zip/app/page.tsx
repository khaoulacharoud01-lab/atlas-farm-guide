"use client";

import { useState } from "react";
import { DEFAULT_PRIORITIES, PRIORITY_LABELS, scoreStrategies } from "./lib/rotationEngine";
import type { FarmerPriorities, PriorityKey, RotationStrategy } from "./lib/types";

export default function Home() {
  const [priorities, setPriorities] = useState<FarmerPriorities>(DEFAULT_PRIORITIES);
  const [strategies, setStrategies] = useState<RotationStrategy[]>([]);
  
  // بيانات ناسا
  const [nasaData, setNasaData] = useState<{ temp: number; rain: number } | null>(null);
  const [loadingNasa, setLoadingNasa] = useState(false);

  const handleSliderChange = (key: PriorityKey, value: number) => {
    setPriorities((prev) => ({ ...prev, [key]: value }));
  };

  const calculateStrategies = () => {
    const result = scoreStrategies(priorities);
    setStrategies(result);
  };

  // دالة جلب البيانات من NASA POWER API
  const fetchNasaData = async () => {
    setLoadingNasa(true);
    try {
      // إحداثيات مزرعة تجريبية (أيوا، أمريكا)
      const lat = 42.03;
      const lon = -93.63;
      const url = `https://power.larc.nasa.gov/api/temporal/daily/point?parameters=T2M,PRECTOTCORR&community=AG&longitude=${lon}&latitude=${lat}&start=20231001&end=20231031&format=JSON`;
      
      const res = await fetch(url);
      const data = await res.json();
      
      const temps = Object.values(data.properties.parameter.T2M) as number[];
      const rains = Object.values(data.properties.parameter.PRECTOTCORR) as number[];

      const avgTemp = temps.reduce((a, b) => a + b, 0) / temps.length;
      const totalRain = rains.reduce((a, b) => a + b, 0);

      setNasaData({ temp: Number(avgTemp.toFixed(1)), rain: Number(totalRain.toFixed(1)) });
    } catch (error) {
      alert("Error fetching NASA data. Please try again.");
    } finally {
      setLoadingNasa(false);
    }
  };

  return (
    <main className="min-h-screen bg-gray-50 p-8 font-sans">
      <div className="max-w-4xl mx-auto space-y-8">
        
        <header>
          <h1 className="text-3xl font-bold text-green-800">RotationIQ</h1>
          <p className="text-gray-600">NASA Space Apps 2026 - Atlas Frontier</p>
        </header>

        {/* كارت بيانات ناسا */}
        <section className="bg-blue-50 p-6 rounded-xl border border-blue-200">
          <div className="flex justify-between items-center">
            <div>
              <h2 className="text-lg font-semibold text-blue-900">NASA Earth Observations</h2>
              <p className="text-sm text-blue-700">Pull real satellite data for this field (Iowa, USA)</p>
            </div>
            <button
              onClick={fetchNasaData}
              disabled={loadingNasa}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg font-medium text-sm"
            >
              {loadingNasa ? "Connecting to Satellite..." : "Fetch NASA Data"}
            </button>
          </div>
          
          {nasaData && (
            <div className="mt-4 grid grid-cols-2 gap-4">
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <p className="text-xs text-gray-500 uppercase">Avg Temperature (Oct)</p>
                <p className="text-xl font-bold text-blue-800">{nasaData.temp} °C</p>
              </div>
              <div className="bg-white p-3 rounded-lg shadow-sm">
                <p className="text-xs text-gray-500 uppercase">Total Precipitation (Oct)</p>
                <p className="text-xl font-bold text-blue-800">{nasaData.rain} mm</p>
              </div>
            </div>
          )}
        </section>

        <section className="bg-white p-6 rounded-xl shadow-sm border border-gray-200">
          <h2 className="text-xl font-semibold mb-4">What matters most to you?</h2>
          <div className="grid grid-cols-2 gap-4">
            {(Object.keys(PRIORITY_LABELS) as PriorityKey[]).map((key) => (
              <div key={key} className="flex flex-col">
                <label className="text-sm font-medium text-gray-700 flex justify-between">
                  <span>{PRIORITY_LABELS[key]}</span>
                  <span className="text-green-700">{priorities[key]}/10</span>
                </label>
                <input
                  type="range"
                  min="0"
                  max="10"
                  value={priorities[key]}
                  onChange={(e) => handleSliderChange(key, Number(e.target.value))}
                  className="mt-1 accent-green-600"
                />
              </div>
            ))}
          </div>
          <button
            onClick={calculateStrategies}
            className="mt-6 w-full bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-4 rounded-lg transition-colors"
          >
            Compare Rotation Strategies
          </button>
        </section>

        {strategies.length > 0 && (
          <section className="space-y-4">
            <h2 className="text-xl font-semibold">Your Recommended Strategies</h2>
            <div className="grid gap-4 md:grid-cols-3">
              {strategies.map((strategy, index) => (
                <div
                  key={strategy.id}
                  className={`bg-white p-4 rounded-xl shadow-sm border ${
                    index === 0 ? "border-green-500 ring-2 ring-green-200" : "border-gray-200"
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="font-bold text-lg">{strategy.name}</h3>
                    <span className="bg-green-100 text-green-800 text-xs font-bold px-2 py-1 rounded-full">
                      {strategy.overallScore}/10
                    </span>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{strategy.description}</p>
                  
                  <div className="space-y-2 text-xs">
                    <p><strong>Crops:</strong> {strategy.crops.join(" → ")}</p>
                    <p className="text-green-700"><strong>Evidence:</strong> {strategy.evidence[0]}</p>
                    <p className="text-amber-700"><strong>Risk:</strong> {strategy.risks[0]}</p>
                    <div className="mt-3 pt-3 border-t border-gray-100 text-gray-600 italic">
                      "{strategy.narrative}"
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}

      </div>
    </main>
  );
}